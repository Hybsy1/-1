# ProGuard rules for TouchInjector
# Keep all native-related classes
-keep class com.touchinjector.** { *; }
