/*
 * touch_injector.c
 *
 * uinput Type B multi-touch injector for Android (requires root).
 *
 * Protocol:
 *   stdin line commands:
 *     CONFIG <x> <y> <interval_ms> <duration_ms> <offset_px> <jitter_ms>
 *     START
 *     STOP
 *     QUIT
 *
 * All time values are in milliseconds.
 * offset_px and jitter_ms define the maximum random deviation applied each
 * cycle (uniform distribution).
 */

#include <errno.h>
#include <fcntl.h>
#include <linux/input.h>
#include <linux/uinput.h>
#include <pthread.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

/* ── global state (protected by lock) ─────────────────────────────── */
static pthread_mutex_t g_lock = PTHREAD_MUTEX_INITIALIZER;
static volatile int g_running = 0; /* click-loop active? */
static volatile int g_quit = 0;    /* whole process should exit? */

static int g_uinput_fd = -1;

/* configurable parameters */
static int g_target_x = 500;
static int g_target_y = 800;
static int g_interval_ms = 100; /* time between clicks (up→next down) */
static int g_duration_ms = 50;  /* press hold time (down→up) */
static int g_offset_px = 5;     /* max random position jitter (pixels) */
static int g_jitter_ms = 20;    /* max random interval jitter (ms) */

static int g_screen_w = 1080;
static int g_screen_h = 1920;

/* ── helper: write a single input_event ───────────────────────────── */
static int write_event(int fd, uint16_t type, uint16_t code, int32_t value) {
  struct input_event ev;
  memset(&ev, 0, sizeof(ev));
  ev.type = type;
  ev.code = code;
  ev.value = value;
  gettimeofday(&ev.time, NULL);
  if (write(fd, &ev, sizeof(ev)) != sizeof(ev)) {
    fprintf(stderr, "[!] write_event failed: %s\n", strerror(errno));
    return -1;
  }
  return 0;
}

/* ── helper: uniform random in [0, max] ───────────────────────────── */
static int rand_range(int max) {
  if (max <= 0)
    return 0;
  return rand() % (max + 1);
}

/* ── clamp a coordinate to screen bounds ──────────────────────────── */
static int clamp_coord(int val, int max) {
  if (val < 0)
    return 0;
  if (val >= max)
    return max - 1;
  return val;
}

/* ── inject a single tap (down → wait → up) ───────────────────────── */
static int inject_tap(int fd, int x, int y, int duration_ms) {
  struct timespec ts;

  /* DOWN */
  if (write_event(fd, EV_ABS, ABS_MT_SLOT, 0) < 0)
    return -1;
  if (write_event(fd, EV_ABS, ABS_MT_TRACKING_ID, 0) < 0)
    return -1;
  if (write_event(fd, EV_ABS, ABS_MT_POSITION_X, x) < 0)
    return -1;
  if (write_event(fd, EV_ABS, ABS_MT_POSITION_Y, y) < 0)
    return -1;
  if (write_event(fd, EV_ABS, ABS_MT_PRESSURE, 50) < 0)
    return -1;
  if (write_event(fd, EV_ABS, ABS_MT_TOUCH_MAJOR, 10) < 0)
    return -1;
  if (write_event(fd, EV_KEY, BTN_TOUCH, 1) < 0)
    return -1;
  if (write_event(fd, EV_SYN, SYN_REPORT, 0) < 0)
    return -1;

  /* hold */
  ts.tv_sec = duration_ms / 1000;
  ts.tv_nsec = (duration_ms % 1000) * 1000000L;
  nanosleep(&ts, NULL);

  /* UP */
  if (write_event(fd, EV_ABS, ABS_MT_SLOT, 0) < 0)
    return -1;
  if (write_event(fd, EV_ABS, ABS_MT_TRACKING_ID, -1) < 0)
    return -1;
  if (write_event(fd, EV_KEY, BTN_TOUCH, 0) < 0)
    return -1;
  if (write_event(fd, EV_SYN, SYN_REPORT, 0) < 0)
    return -1;

  return 0;
}

/* ── click-loop thread ────────────────────────────────────────────── */
static void *click_loop(void *arg) {
  (void)arg;

  while (1) {
    pthread_mutex_lock(&g_lock);
    int running = g_running;
    int quit = g_quit;
    pthread_mutex_unlock(&g_lock);

    if (quit)
      break;
    if (!running) {
      usleep(50000); /* 50 ms poll when idle */
      continue;
    }

    /* read current config under lock */
    pthread_mutex_lock(&g_lock);
    int base_x = g_target_x;
    int base_y = g_target_y;
    int interval = g_interval_ms;
    int duration = g_duration_ms;
    int offset = g_offset_px;
    int jitter = g_jitter_ms;
    int scr_w = g_screen_w;
    int scr_h = g_screen_h;
    running = g_running;
    pthread_mutex_unlock(&g_lock);

    if (!running)
      continue;

    /* apply position offset (signed random) */
    int dx = rand_range(offset * 2) - offset;
    int dy = rand_range(offset * 2) - offset;
    int x = clamp_coord(base_x + dx, scr_w);
    int y = clamp_coord(base_y + dy, scr_h);

    inject_tap(g_uinput_fd, x, y, duration);

    /* compute wait: base interval + random jitter */
    int wait_ms = interval + rand_range(jitter);
    if (wait_ms < 1)
      wait_ms = 1;

    struct timespec ts;
    ts.tv_sec = wait_ms / 1000;
    ts.tv_nsec = (wait_ms % 1000) * 1000000L;
    nanosleep(&ts, NULL);
  }

  return NULL;
}

/* ── setup uinput device ──────────────────────────────────────────── */
static int setup_uinput(const char *path, int w, int h) {
  int fd = open(path, O_WRONLY | O_NONBLOCK);
  if (fd < 0) {
    fprintf(stderr, "[!] open %s failed: %s\n", path, strerror(errno));
    return -1;
  }

  /* enable event types */
  if (ioctl(fd, UI_SET_EVBIT, EV_SYN) < 0)
    goto fail;
  if (ioctl(fd, UI_SET_EVBIT, EV_KEY) < 0)
    goto fail;
  if (ioctl(fd, UI_SET_EVBIT, EV_ABS) < 0)
    goto fail;

  /* BTN_TOUCH */
  if (ioctl(fd, UI_SET_KEYBIT, BTN_TOUCH) < 0)
    goto fail;

  /* ABS_MT capabilities */
  if (ioctl(fd, UI_SET_ABSBIT, ABS_MT_SLOT) < 0)
    goto fail;
  if (ioctl(fd, UI_SET_ABSBIT, ABS_MT_TRACKING_ID) < 0)
    goto fail;
  if (ioctl(fd, UI_SET_ABSBIT, ABS_MT_POSITION_X) < 0)
    goto fail;
  if (ioctl(fd, UI_SET_ABSBIT, ABS_MT_POSITION_Y) < 0)
    goto fail;
  if (ioctl(fd, UI_SET_ABSBIT, ABS_MT_PRESSURE) < 0)
    goto fail;
  if (ioctl(fd, UI_SET_ABSBIT, ABS_MT_TOUCH_MAJOR) < 0)
    goto fail;

  /* configure axis ranges */
  struct uinput_abs_setup abs_setup;
  memset(&abs_setup, 0, sizeof(abs_setup));

  abs_setup.code = ABS_MT_SLOT;
  abs_setup.absinfo.minimum = 0;
  abs_setup.absinfo.maximum = 9;
  if (ioctl(fd, UI_ABS_SETUP, &abs_setup) < 0)
    goto fail;

  abs_setup.code = ABS_MT_TRACKING_ID;
  abs_setup.absinfo.minimum = 0;
  abs_setup.absinfo.maximum = 65535;
  if (ioctl(fd, UI_ABS_SETUP, &abs_setup) < 0)
    goto fail;

  abs_setup.code = ABS_MT_POSITION_X;
  abs_setup.absinfo.minimum = 0;
  abs_setup.absinfo.maximum = w - 1;
  if (ioctl(fd, UI_ABS_SETUP, &abs_setup) < 0)
    goto fail;

  abs_setup.code = ABS_MT_POSITION_Y;
  abs_setup.absinfo.minimum = 0;
  abs_setup.absinfo.maximum = h - 1;
  if (ioctl(fd, UI_ABS_SETUP, &abs_setup) < 0)
    goto fail;

  abs_setup.code = ABS_MT_PRESSURE;
  abs_setup.absinfo.minimum = 0;
  abs_setup.absinfo.maximum = 255;
  if (ioctl(fd, UI_ABS_SETUP, &abs_setup) < 0)
    goto fail;

  abs_setup.code = ABS_MT_TOUCH_MAJOR;
  abs_setup.absinfo.minimum = 0;
  abs_setup.absinfo.maximum = 255;
  if (ioctl(fd, UI_ABS_SETUP, &abs_setup) < 0)
    goto fail;

  /* set device properties */
  if (ioctl(fd, UI_SET_PROPBIT, INPUT_PROP_DIRECT) < 0)
    goto fail;

  /* device identity */
  struct uinput_setup usetup;
  memset(&usetup, 0, sizeof(usetup));
  strncpy(usetup.name, "synaptics-touch", UINPUT_MAX_NAME_SIZE - 1);
  usetup.id.bustype = BUS_VIRTUAL;
  usetup.id.vendor = 0x06cb;
  usetup.id.product = 0xcd46;
  usetup.id.version = 1;

  if (ioctl(fd, UI_DEV_SETUP, &usetup) < 0)
    goto fail;
  if (ioctl(fd, UI_DEV_CREATE) < 0)
    goto fail;

  fprintf(stderr, "[+] uinput device created: %s (%dx%d)\n",
          usetup.name, w, h);
  return fd;

fail:
  fprintf(stderr, "[!] uinput setup failed: %s\n", strerror(errno));
  close(fd);
  return -1;
}

/* ── shutdown ─────────────────────────────────────────────────────── */
static void destroy_uinput(int fd) {
  if (fd >= 0) {
    ioctl(fd, UI_DEV_DESTROY);
    close(fd);
  }
}

/* ── main ─────────────────────────────────────────────────────────── */
int main(int argc, char *argv[]) {
  const char *uinput_path = "/dev/uinput";
  int w = 1080, h = 1920;

  /* parse optional args: touch_injector [uinput_path] [w] [h] */
  if (argc >= 2)
    uinput_path = argv[1];
  if (argc >= 3)
    w = atoi(argv[2]);
  if (argc >= 4)
    h = atoi(argv[3]);

  g_screen_w = w;
  g_screen_h = h;

  /* seed RNG */
  srand((unsigned)time(NULL) ^ (unsigned)getpid());

  /* ignore SIGPIPE — we detect stdin close via select/read */
  signal(SIGPIPE, SIG_IGN);

  /* setup uinput */
  g_uinput_fd = setup_uinput(uinput_path, w, h);
  if (g_uinput_fd < 0) {
    fprintf(stderr, "[!] cannot open uinput. Are you root?\n");
    return 1;
  }

  /* start click-loop thread */
  pthread_t tid;
  if (pthread_create(&tid, NULL, click_loop, NULL) != 0) {
    fprintf(stderr, "[!] pthread_create failed\n");
    destroy_uinput(g_uinput_fd);
    return 1;
  }

  /* stdin command loop */
  char line[256];
  fprintf(stderr, "[+] ready, waiting for commands on stdin...\n");

  while (!g_quit) {
    fd_set rfds;
    FD_ZERO(&rfds);
    FD_SET(STDIN_FILENO, &rfds);

    struct timeval tv;
    tv.tv_sec = 0;
    tv.tv_usec = 200000; /* 200 ms poll */

    int ret = select(STDIN_FILENO + 1, &rfds, NULL, NULL, &tv);
    if (ret < 0) {
      if (errno == EINTR)
        continue;
      break;
    }
    if (ret == 0)
      continue; /* timeout, loop */

    if (!fgets(line, sizeof(line), stdin))
      break; /* EOF → parent closed pipe */

    /* strip newline */
    size_t len = strlen(line);
    while (len > 0 && (line[len - 1] == '\n' || line[len - 1] == '\r'))
      line[--len] = '\0';

    /* ── parse commands ───────────────────────────────────── */
    if (strncmp(line, "START", 5) == 0) {
      pthread_mutex_lock(&g_lock);
      g_running = 1;
      pthread_mutex_unlock(&g_lock);
      fprintf(stderr, "[+] START\n");
    } else if (strncmp(line, "STOP", 4) == 0) {
      pthread_mutex_lock(&g_lock);
      g_running = 0;
      pthread_mutex_unlock(&g_lock);
      fprintf(stderr, "[+] STOP\n");
    } else if (strncmp(line, "QUIT", 4) == 0) {
      pthread_mutex_lock(&g_lock);
      g_quit = 1;
      g_running = 0;
      pthread_mutex_unlock(&g_lock);
      fprintf(stderr, "[+] QUIT\n");
      break;
    } else if (strncmp(line, "CONFIG", 6) == 0) {
      int nx, ny, ni, nd, no, nj;
      int parsed = sscanf(line, "CONFIG %d %d %d %d %d %d", &nx, &ny, &ni,
                          &nd, &no, &nj);
      if (parsed == 6) {
        pthread_mutex_lock(&g_lock);
        g_target_x = nx;
        g_target_y = ny;
        g_interval_ms = ni;
        g_duration_ms = nd;
        g_offset_px = no;
        g_jitter_ms = nj;
        pthread_mutex_unlock(&g_lock);
        fprintf(stderr,
                "[+] CONFIG x=%d y=%d interval=%dms duration=%dms "
                "offset=+-%dpx jitter=+-%dms\n",
                nx, ny, ni, nd, no, nj);
      } else {
        fprintf(stderr, "[!] bad CONFIG: %s\n", line);
      }
    } else if (line[0] != '\0') {
      fprintf(stderr, "[!] unknown command: %s\n", line);
    }
  }

  /* shutdown */
  g_quit = 1;
  g_running = 0;
  pthread_join(tid, NULL);

  destroy_uinput(g_uinput_fd);
  fprintf(stderr, "[+] touch_injector exiting cleanly\n");
  return 0;
}
