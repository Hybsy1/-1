package com.touchinjector;

import android.content.Context;
import android.content.res.AssetManager;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.WindowManager;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;

/**
 * Manages the native touch_injector process running under root via su.
 *
 * Lifecycle:
 *   1. extractNativeBinary() — copy the ABI-matched binary from assets to app
 *      private dir and chmod 0700.
 *   2. start() — launch "su -c <binary> <uinput> <w> <h>", obtain stdin/stdout
 *      pipes.
 *   3. sendConfig(...) / sendStart() / sendStop() — write commands to stdin.
 *   4. stop() — send QUIT, close pipes, wait for process exit.
 */
public class InjectorController {

    private static final String TAG = "InjectorController";

    private static final String UINPUT_PATH = "/dev/uinput";
    private static final String NATIVE_BIN_NAME = "touch_injector";

    private final Context mContext;
    private final SettingsManager mSettings;

    private Process mProcess;
    private OutputStreamWriter mStdin;
    private Thread mStderrReader;

    public InjectorController(Context context, SettingsManager settings) {
        mContext = context;
        mSettings = settings;
    }

    /* ── extract native binary from assets ──────────────────────────── */

    private String getNativeBinPath() throws IOException {
        String abi = Build.SUPPORTED_ABIS[0]; // e.g. "arm64-v8a"
        File binFile = new File(mContext.getFilesDir(), NATIVE_BIN_NAME);
        if (binFile.exists() && binFile.canExecute()) {
            return binFile.getAbsolutePath();
        }

        // copy from assets
        String assetPath = "native/" + abi + "/" + NATIVE_BIN_NAME;
        AssetManager am = mContext.getAssets();

        try (InputStream is = am.open(assetPath);
             FileOutputStream os = new FileOutputStream(binFile)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) > 0) {
                os.write(buf, 0, n);
            }
        }

        // set executable
        binFile.setExecutable(true, false);
        Log.i(TAG, "Extracted native binary: " + binFile.getAbsolutePath());
        return binFile.getAbsolutePath();
    }

    /* ── screen dimensions ──────────────────────────────────────────── */

    private int[] getScreenSize() {
        WindowManager wm = (WindowManager) mContext.getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics metrics = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(metrics);
        return new int[]{metrics.widthPixels, metrics.heightPixels};
    }

    /* ── start the root process ─────────────────────────────────────── */

    public boolean start() {
        if (mProcess != null && isAlive()) {
            Log.w(TAG, "Already running");
            return true;
        }
        stop(); // ensure clean state

        try {
            String binPath = getNativeBinPath();
            int[] wh = getScreenSize();

            // Build command: su -c '<bin> <uinput> <w> <h>'
            String cmd = binPath + " " + UINPUT_PATH + " " + wh[0] + " " + wh[1];
            Log.i(TAG, "Launching: su -c " + cmd);

            mProcess = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});

            mStdin = new OutputStreamWriter(mProcess.getOutputStream(), StandardCharsets.UTF_8);

            // drain stderr in background
            mStderrReader = new Thread(() -> {
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(mProcess.getErrorStream()))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        Log.d(TAG, "[native] " + line);
                    }
                } catch (IOException ignored) {
                }
            }, "stderr-reader");
            mStderrReader.setDaemon(true);
            mStderrReader.start();

            // send initial config
            sendConfig();

            Log.i(TAG, "Process started successfully");
            return true;

        } catch (IOException e) {
            Log.e(TAG, "Failed to start native process", e);
            stop();
            return false;
        }
    }

    /* ── command helpers ────────────────────────────────────────────── */

    private void writeCommand(String cmd) {
        if (mStdin == null) return;
        try {
            mStdin.write(cmd + "\n");
            mStdin.flush();
        } catch (IOException e) {
            Log.e(TAG, "writeCommand failed: " + cmd, e);
        }
    }

    public void sendConfig() {
        int x = mSettings.getTargetX();
        int y = mSettings.getTargetY();
        int interval = mSettings.getIntervalMs();
        int duration = mSettings.getDurationMs();
        int offset = mSettings.getOffsetPx();
        int jitter = mSettings.getJitterMs();

        String cmd = "CONFIG " + x + " " + y + " " + interval + " "
                + duration + " " + offset + " " + jitter;
        writeCommand(cmd);
    }

    public void sendStart() {
        writeCommand("START");
    }

    public void sendStop() {
        writeCommand("STOP");
    }

    /* ── lifecycle ──────────────────────────────────────────────────── */

    public boolean isAlive() {
        return mProcess != null && mProcess.isAlive();
    }

    public void stop() {
        if (mProcess != null) {
            try {
                writeCommand("QUIT");
                mStdin.close();
            } catch (IOException ignored) {
            }
            try {
                mProcess.waitFor();
            } catch (InterruptedException ignored) {
                mProcess.destroyForcibly();
            }
            mProcess = null;
            mStdin = null;
        }
        if (mStderrReader != null) {
            mStderrReader.interrupt();
            mStderrReader = null;
        }
    }
}
