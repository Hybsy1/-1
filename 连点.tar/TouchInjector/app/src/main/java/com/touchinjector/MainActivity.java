package com.touchinjector;

import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
import android.text.InputType;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Main settings UI.
 *
 * Parameters (all in ms / px):
 *   - Target X / Y   : click coordinates
 *   - Interval       : time between clicks (up→next down)
 *   - Duration       : press hold time (down→up)
 *   - Offset         : max random position jitter (pixels)
 *   - Jitter         : max random interval jitter (ms)
 *   - Alpha          : overlay circle transparency
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private static final int REQUEST_OVERLAY = 100;

    private SettingsManager mSettings;

    private EditText mEditTargetX;
    private EditText mEditTargetY;
    private SeekBar mSeekInterval;
    private SeekBar mSeekDuration;
    private SeekBar mSeekOffset;
    private SeekBar mSeekJitter;
    private SeekBar mSeekAlpha;

    private TextView mLabelInterval;
    private TextView mLabelDuration;
    private TextView mLabelOffset;
    private TextView mLabelJitter;
    private TextView mLabelAlpha;

    private Button mBtnToggle;
    private Button mBtnHide;

    private boolean mServiceBound = false;
    private OverlayService mService;

    private final ServiceConnection mConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            mServiceBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mServiceBound = false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mSettings = new SettingsManager(this);

        // Build UI programmatically for clarity
        ScrollView scrollView = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(16));

        // ── Title ──
        TextView title = new TextView(this);
        title.setText("TouchInjector");
        title.setTextSize(20);
        title.setPadding(0, 0, 0, dp(12));
        root.addView(title);

        // ── Target X ──
        root.addView(label("Target X (px)"));
        mEditTargetX = editNum(mSettings.getTargetX());
        root.addView(mEditTargetX);

        // ── Target Y ──
        root.addView(label("Target Y (px)"));
        mEditTargetY = editNum(mSettings.getTargetY());
        root.addView(mEditTargetY);

        // ── Interval ──
        root.addView(label("Click Interval (ms)"));
        mLabelInterval = valLabel();
        root.addView(mLabelInterval);
        mSeekInterval = seekBar(1, 1000, mSettings.getIntervalMs());
        root.addView(mSeekInterval);

        // ── Duration ──
        root.addView(label("Hold Duration (ms)"));
        mLabelDuration = valLabel();
        root.addView(mLabelDuration);
        mSeekDuration = seekBar(1, 500, mSettings.getDurationMs());
        root.addView(mSeekDuration);

        // ── Offset ──
        root.addView(label("Random Position Offset (px)"));
        mLabelOffset = valLabel();
        root.addView(mLabelOffset);
        mSeekOffset = seekBar(0, 50, mSettings.getOffsetPx());
        root.addView(mSeekOffset);

        // ── Jitter ──
        root.addView(label("Random Interval Jitter (ms)"));
        mLabelJitter = valLabel();
        root.addView(mLabelJitter);
        mSeekJitter = seekBar(0, 200, mSettings.getJitterMs());
        root.addView(mSeekJitter);

        // ── Alpha ──
        root.addView(label("Overlay Alpha (0-255)"));
        mLabelAlpha = valLabel();
        root.addView(mLabelAlpha);
        mSeekAlpha = seekBar(32, 255, 128);
        root.addView(mSeekAlpha);

        // ── Buttons ──
        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);
        btnRow.setPadding(0, dp(12), 0, 0);

        mBtnToggle = new Button(this);
        mBtnToggle.setText(isServiceRunning() ? "Stop Service" : "Start Service");
        mBtnToggle.setOnClickListener(v -> toggleService());
        btnRow.addView(mBtnToggle);

        mBtnHide = new Button(this);
        mBtnHide.setText("Hide UI");
        mBtnHide.setOnClickListener(v -> moveTaskToBack(true));
        btnRow.addView(mBtnHide);

        root.addView(btnRow);

        // ── Info ──
        TextView info = new TextView(this);
        info.setText("Press and hold the floating circle to start clicking.\n"
                + "Move the circle by dragging.\n"
                + "Settings take effect on the next press.\n"
                + "Requires ROOT and overlay permission.");
        info.setTextSize(12);
        info.setPadding(0, dp(16), 0, 0);
        root.addView(info);

        scrollView.addView(root);
        setContentView(scrollView);

        initSeekListeners();
        updateSeekLabels();
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkOverlayPermission();
        updateToggleButton();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OVERLAY) {
            if (Settings.canDrawOverlays(this)) {
                startServiceIfNeeded();
            } else {
                Toast.makeText(this, "Overlay permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    /* ── permission ──────────────────────────────────────────────────── */

    private void checkOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQUEST_OVERLAY);
            } else {
                startServiceIfNeeded();
            }
        } else {
            startServiceIfNeeded();
        }
    }

    /* ── service control ─────────────────────────────────────────────── */

    private void startServiceIfNeeded() {
        if (!isServiceRunning()) {
            Intent intent = new Intent(this, OverlayService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
            bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
            updateToggleButton();
        }
    }

    private void toggleService() {
        if (isServiceRunning()) {
            Intent intent = new Intent(this, OverlayService.class);
            if (mServiceBound) {
                unbindService(mConnection);
                mServiceBound = false;
            }
            stopService(intent);
        } else {
            applySettings();
            Intent intent = new Intent(this, OverlayService.class);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent);
            } else {
                startService(intent);
            }
            bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
        }
        updateToggleButton();
    }

    private boolean isServiceRunning() {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        if (manager != null) {
            for (ActivityManager.RunningServiceInfo service :
                    manager.getRunningServices(Integer.MAX_VALUE)) {
                if (OverlayService.class.getName().equals(
                        service.service.getClassName())) {
                    return true;
                }
            }
        }
        return false;
    }

    private void updateToggleButton() {
        if (mBtnToggle != null) {
            mBtnToggle.setText(isServiceRunning() ? "Stop Service" : "Start Service");
        }
    }

    /* ── settings ────────────────────────────────────────────────────── */

    private int seekVal(SeekBar sb) {
        int min = (int) sb.getTag();
        return sb.getProgress() + min;
    }

    private void applySettings() {
        try {
            mSettings.setTargetX(Integer.parseInt(mEditTargetX.getText().toString().trim()));
            mSettings.setTargetY(Integer.parseInt(mEditTargetY.getText().toString().trim()));
            mSettings.setIntervalMs(seekVal(mSeekInterval));
            mSettings.setDurationMs(seekVal(mSeekDuration));
            mSettings.setOffsetPx(seekVal(mSeekOffset));
            mSettings.setJitterMs(seekVal(mSeekJitter));
            Log.i(TAG, "Settings applied");
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid number in coordinate fields", Toast.LENGTH_SHORT).show();
        }
    }

    /* ── seek bar listeners ──────────────────────────────────────────── */

    private void initSeekListeners() {
        SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateSeekLabels();
                if (fromUser) {
                    applySettings();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                applySettings();
            }
        };

        mSeekInterval.setOnSeekBarChangeListener(listener);
        mSeekDuration.setOnSeekBarChangeListener(listener);
        mSeekOffset.setOnSeekBarChangeListener(listener);
        mSeekJitter.setOnSeekBarChangeListener(listener);
        mSeekAlpha.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                updateSeekLabels();
                if (fromUser && mServiceBound) {
                    // Update overlay alpha in real-time
                    Intent intent = new Intent(MainActivity.this, OverlayService.class);
                    intent.putExtra("alpha", seekVal(mSeekAlpha));
                    startService(intent);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }

    private void updateSeekLabels() {
        mLabelInterval.setText("Interval: " + seekVal(mSeekInterval) + " ms");
        mLabelDuration.setText("Duration: " + seekVal(mSeekDuration) + " ms");
        mLabelOffset.setText("Offset: \u00B1" + seekVal(mSeekOffset) + " px");
        mLabelJitter.setText("Jitter: \u00B1" + seekVal(mSeekJitter) + " ms");
        mLabelAlpha.setText("Alpha: " + (seekVal(mSeekAlpha) + 32) + " / 255");
    }

    /* ── UI helpers ──────────────────────────────────────────────────── */

    private TextView label(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(13);
        tv.setPadding(0, dp(8), 0, dp(2));
        return tv;
    }

    private TextView valLabel() {
        TextView tv = new TextView(this);
        tv.setTextSize(11);
        return tv;
    }

    private EditText editNum(int initial) {
        EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setText(String.valueOf(initial));
        et.setTextSize(14);
        return et;
    }

    private SeekBar seekBar(int min, int max, int initial) {
        SeekBar sb = new SeekBar(this);
        sb.setMax(max - min);
        sb.setProgress(initial - min);
        sb.setTag(min); // store min as offset
        return sb;
    }

    private int dp(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density + 0.5f);
    }
}
