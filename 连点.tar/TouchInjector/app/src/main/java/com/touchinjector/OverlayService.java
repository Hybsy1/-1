package com.touchinjector;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.WindowManager;

import androidx.core.app.NotificationCompat;

/**
 * Foreground service managing the floating touch circle overlay
 * and the native injector lifecycle.
 */
public class OverlayService extends Service
        implements TouchOverlayView.OnPressListener,
                   TouchOverlayView.WindowManagerLayoutParamsHelper {

    private static final String TAG = "OverlayService";
    private static final String CHANNEL_ID = "touch_injector_channel";
    private static final int NOTIFICATION_ID = 1;

    private static final int OVERLAY_SIZE_DP = 72; // diameter of the circle

    private WindowManager mWindowManager;
    private TouchOverlayView mOverlayView;
    private InjectorController mInjector;
    private SettingsManager mSettings;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();

        mSettings = new SettingsManager(this);
        mInjector = new InjectorController(this, mSettings);
        mWindowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Notification notification = buildNotification();
        startForeground(NOTIFICATION_ID, notification);

        if (mOverlayView == null) {
            addOverlay();
        }

        // handle alpha update from settings
        if (intent != null && intent.hasExtra("alpha")) {
            int alpha = intent.getIntExtra("alpha", 128);
            updateOverlayAlpha(alpha);
        }

        // start the native process if not already running
        if (!mInjector.isAlive()) {
            mInjector.start();
        }

        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        if (mOverlayView != null) {
            mWindowManager.removeView(mOverlayView);
            mOverlayView = null;
        }
        mInjector.stop();
        stopForeground(true);
        super.onDestroy();
    }

    /* ── overlay ────────────────────────────────────────────────────── */

    private void addOverlay() {
        mOverlayView = new TouchOverlayView(this);
        mOverlayView.setOnPressListener(this);
        mOverlayView.setLayoutParamsHelper(this);
        mOverlayView.setOverlayAlpha(128); // 50% opacity default

        int sizePx = dpToPx(OVERLAY_SIZE_DP);

        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                sizePx,
                sizePx,
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);

        params.gravity = Gravity.TOP | Gravity.START;

        // place at top-center initially
        DisplayMetrics metrics = new DisplayMetrics();
        mWindowManager.getDefaultDisplay().getRealMetrics(metrics);
        params.x = (metrics.widthPixels - sizePx) / 2;
        params.y = metrics.heightPixels / 4;

        mWindowManager.addView(mOverlayView, params);
        Log.i(TAG, "Overlay added");
    }

    public void updateOverlayAlpha(int alpha) {
        if (mOverlayView != null) {
            mOverlayView.setOverlayAlpha(alpha);
        }
    }

    /* ── press listener ─────────────────────────────────────────────── */

    @Override
    public void onPressDown() {
        mInjector.sendConfig(); // sync latest settings
        mInjector.sendStart();
        Log.i(TAG, "Press DOWN → inject START");
    }

    @Override
    public void onPressUp() {
        mInjector.sendStop();
        Log.i(TAG, "Press UP → inject STOP");
    }

    /* ── position helper ────────────────────────────────────────────── */

    @Override
    public void updatePosition(int x, int y) {
        if (mOverlayView != null) {
            WindowManager.LayoutParams lp =
                    (WindowManager.LayoutParams) mOverlayView.getLayoutParams();
            lp.x = x;
            lp.y = y;
            mWindowManager.updateViewLayout(mOverlayView, lp);
        }
    }

    /* ── notification ───────────────────────────────────────────────── */

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Touch Injector",
                    NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Touch injector service is running");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                nm.createNotificationChannel(channel);
            }
        }
    }

    private Notification buildNotification() {
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(
                this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Touch Injector")
                .setContentText("Floating circle active — hold to click")
                .setSmallIcon(android.R.drawable.ic_menu_compass)
                .setContentIntent(pi)
                .setOngoing(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }

    /* ── helpers ────────────────────────────────────────────────────── */

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density + 0.5f);
    }
}
