package com.touchinjector;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Persists all injector parameters via SharedPreferences.
 * All time values in milliseconds.
 */
public class SettingsManager {

    private static final String PREFS_NAME = "touch_injector_prefs";

    private static final String KEY_TARGET_X = "target_x";
    private static final String KEY_TARGET_Y = "target_y";
    private static final String KEY_INTERVAL_MS = "interval_ms";
    private static final String KEY_DURATION_MS = "duration_ms";
    private static final String KEY_OFFSET_PX = "offset_px";
    private static final String KEY_JITTER_MS = "jitter_ms";

    /* defaults */
    private static final int DEFAULT_TARGET_X = 540;
    private static final int DEFAULT_TARGET_Y = 960;
    private static final int DEFAULT_INTERVAL_MS = 100;
    private static final int DEFAULT_DURATION_MS = 50;
    private static final int DEFAULT_OFFSET_PX = 5;
    private static final int DEFAULT_JITTER_MS = 20;

    private final SharedPreferences mPrefs;

    public SettingsManager(Context context) {
        mPrefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    public int getTargetX() {
        return mPrefs.getInt(KEY_TARGET_X, DEFAULT_TARGET_X);
    }

    public void setTargetX(int value) {
        mPrefs.edit().putInt(KEY_TARGET_X, value).apply();
    }

    public int getTargetY() {
        return mPrefs.getInt(KEY_TARGET_Y, DEFAULT_TARGET_Y);
    }

    public void setTargetY(int value) {
        mPrefs.edit().putInt(KEY_TARGET_Y, value).apply();
    }

    public int getIntervalMs() {
        return mPrefs.getInt(KEY_INTERVAL_MS, DEFAULT_INTERVAL_MS);
    }

    public void setIntervalMs(int value) {
        mPrefs.edit().putInt(KEY_INTERVAL_MS, value).apply();
    }

    public int getDurationMs() {
        return mPrefs.getInt(KEY_DURATION_MS, DEFAULT_DURATION_MS);
    }

    public void setDurationMs(int value) {
        mPrefs.edit().putInt(KEY_DURATION_MS, value).apply();
    }

    public int getOffsetPx() {
        return mPrefs.getInt(KEY_OFFSET_PX, DEFAULT_OFFSET_PX);
    }

    public void setOffsetPx(int value) {
        mPrefs.edit().putInt(KEY_OFFSET_PX, value).apply();
    }

    public int getJitterMs() {
        return mPrefs.getInt(KEY_JITTER_MS, DEFAULT_JITTER_MS);
    }

    public void setJitterMs(int value) {
        mPrefs.edit().putInt(KEY_JITTER_MS, value).apply();
    }
}
