package com.touchinjector;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * Circular floating button.
 *
 * When the user presses and holds this circle, the injector starts
 * continuous clicking at the target coordinates. Releasing stops it.
 *
 * The view supports drag-to-move and a configurable alpha for stealth.
 */
public class TouchOverlayView extends View {

    public interface OnPressListener {
        void onPressDown();
        void onPressUp();
    }

    private OnPressListener mListener;

    private final Paint mFillPaint;
    private final Paint mStrokePaint;
    private float mRadius;
    private boolean mPressed = false;

    private int mBaseColor = 0x80_4FC3F7; // semi-transparent blue
    private int mPressedColor = 0xAA_FF7043; // semi-transparent orange
    private int mStrokeColor = 0x40_FFFFFF;

    private float mDownRawX, mDownRawY;
    private float mViewDownX, mViewDownY;
    private WindowManagerLayoutParamsHelper mLayoutParamsHelper;

    public TouchOverlayView(Context context) {
        this(context, null);
    }

    public TouchOverlayView(Context context, AttributeSet attrs) {
        super(context, attrs);
        mFillPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mStrokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        mStrokePaint.setStyle(Paint.Style.STROKE);
        mStrokePaint.setStrokeWidth(2f);
        mStrokePaint.setColor(mStrokeColor);
    }

    public void setOnPressListener(OnPressListener listener) {
        mListener = listener;
    }

    public void setLayoutParamsHelper(WindowManagerLayoutParamsHelper helper) {
        mLayoutParamsHelper = helper;
    }

    /**
     * Set the overall alpha of the floating circle (0..255).
     */
    public void setOverlayAlpha(int alpha) {
        mBaseColor = (mBaseColor & 0x00FFFFFF) | (alpha << 24);
        mPressedColor = (mPressedColor & 0x00FFFFFF) | (Math.min(alpha + 40, 255) << 24);
        mStrokeColor = (mStrokeColor & 0x00FFFFFF) | ((alpha / 2) << 24);
        mStrokePaint.setColor(mStrokeColor);
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        mRadius = Math.min(w, h) / 2f;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;

        int color = mPressed ? mPressedColor : mBaseColor;

        // radial gradient for depth
        RadialGradient gradient = new RadialGradient(
                cx, cy, mRadius,
                new int[]{Color.argb(0x60, 255, 255, 255), color},
                new float[]{0.3f, 1.0f},
                Shader.TileMode.CLAMP);
        mFillPaint.setShader(gradient);

        canvas.drawCircle(cx, cy, mRadius, mFillPaint);
        canvas.drawCircle(cx, cy, mRadius - 1f, mStrokePaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN: {
                mPressed = true;
                invalidate();

                mDownRawX = event.getRawX();
                mDownRawY = event.getRawY();
                if (getLayoutParams() instanceof android.view.WindowManager.LayoutParams) {
                    android.view.WindowManager.LayoutParams lp =
                            (android.view.WindowManager.LayoutParams) getLayoutParams();
                    mViewDownX = lp.x;
                    mViewDownY = lp.y;
                }

                if (mListener != null) {
                    mListener.onPressDown();
                }
                return true;
            }

            case MotionEvent.ACTION_MOVE: {
                float dx = event.getRawX() - mDownRawX;
                float dy = event.getRawY() - mDownRawY;

                if (Math.abs(dx) > 5 || Math.abs(dy) > 5) {
                    if (mLayoutParamsHelper != null) {
                        mLayoutParamsHelper.updatePosition(
                                (int) (mViewDownX + dx),
                                (int) (mViewDownY + dy));
                    }
                }
                return true;
            }

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                if (mPressed) {
                    mPressed = false;
                    invalidate();
                    if (mListener != null) {
                        mListener.onPressUp();
                    }
                }
                return true;
            }
        }
        return super.onTouchEvent(event);
    }

    /**
     * Callback interface used by OverlayService to update WindowManager
     * LayoutParams and trigger re-layout.
     */
    public interface WindowManagerLayoutParamsHelper {
        void updatePosition(int x, int y);
    }
}
