#!/bin/bash
# Build script for TouchInjector
# Prerequisites:
#   - Android SDK (set ANDROID_HOME or ANDROID_SDK_ROOT)
#   - JDK 11+
#   - NDK (or let AGP download it automatically)

set -e

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "=== Building TouchInjector ==="
echo "Project: ${PROJECT_DIR}"

# Check for Gradle wrapper, use it if present
if [ -f "${PROJECT_DIR}/gradlew" ]; then
    GRADLE="${PROJECT_DIR}/gradlew"
else
    GRADLE="gradle"
    echo "[!] No gradlew found; install wrapper with: gradle wrapper"
fi

# Build debug APK
"${GRADLE}" -p "${PROJECT_DIR}" assembleDebug

APK_PATH="${PROJECT_DIR}/app/build/outputs/apk/debug/app-debug.apk"
if [ -f "${APK_PATH}" ]; then
    echo ""
    echo "=== Build successful ==="
    echo "APK: ${APK_PATH}"
    echo ""
    echo "Install on device (with adb):"
    echo "  adb install -r ${APK_PATH}"
    echo ""
    echo "On-device steps after install:"
    echo "  1. Open TouchInjector app"
    echo "  2. Grant overlay permission when prompted"
    echo "  3. Grant root access when su dialog appears"
    echo "  4. Configure target coordinates and timing parameters"
    echo "  5. Press Start Service"
    echo "  6. Hold the floating circle to begin clicking"
else
    echo "[!] Build failed — check errors above"
    exit 1
fi
